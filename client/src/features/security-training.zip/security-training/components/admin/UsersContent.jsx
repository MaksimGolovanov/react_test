// src/features/security-training/components/admin/UsersContent.jsx
import React, { useState, useEffect } from "react";
import { observer } from "mobx-react-lite";
import AvatarWithFallback from "../../../../Components/AvatarWithFallback/AvatarWithFallback";
import {
  Alert,
  Card,
  Table,
  Button,
  Space,
  Typography,
  Progress,
  Tag,
  Modal,
  Form,
  Input,
  Select,
  InputNumber,
  DatePicker,
  message,
  Popconfirm,
  Tooltip,
  Badge,
  Row,
  Col,
  Statistic,
} from "antd";
import {
  PlusOutlined,
  DownloadOutlined,
  TrophyOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  UserAddOutlined,
  TeamOutlined,
  BookOutlined,
  ClockCircleOutlined,
  StarOutlined,
  ReloadOutlined,
} from "@ant-design/icons";
import moment from "moment";
import securityTrainingStore from "../../store/SecurityTrainingStore";

const { Title, Text } = Typography;
const { Option } = Select;
const { TextArea } = Input;

const UsersContent = observer(() => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMode, setModalMode] = useState("create"); // 'create' или 'edit'
  const [currentUser, setCurrentUser] = useState(null);
  const [deleteConfirmVisible, setDeleteConfirmVisible] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [form] = Form.useForm();

  // Загрузка пользователей из store
  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
        await securityTrainingStore.fetchAllUsersData();
        
        // Используем метод getTrainingStats из store
        const userData = securityTrainingStore.getTrainingStats?.() || [];
        
        // Проверяем, что это массив
        if (Array.isArray(userData)) {
            setUsers(userData);
        } else {
            console.error('getTrainingStats не вернул массив:', userData);
            setUsers([]);
        }
    } catch (error) {
        console.error("Ошибка загрузки пользователей:", error);
        message.error("Не удалось загрузить пользователей");
        setUsers([]);
    } finally {
        setLoading(false);
    }
};

  const handleCreateUser = () => {
    setModalMode("create");
    setCurrentUser(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEditUser = (user) => {
    setModalMode("edit");
    setCurrentUser(user);
    form.setFieldsValue({
      login: user.login,
      tabNumber: user.tabNumber,
      description: user.description,
      roles: user.roles || ["ST"],
      password: "",
      passwordConfirm: "",
      completed_courses: user.completed_courses || 0,
      average_score: user.average_score || 0,
      total_training_time: user.total_training_time || 0,
    });
    setModalVisible(true);
  };

  const handleViewUser = (user) => {
    Modal.info({
      title: `Подробная информация: ${user.login}`,
      width: 600,
      content: (
        <div>
          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={12}>
              <Statistic 
                title="Пройдено курсов" 
                value={user.completed_courses} 
                prefix={<BookOutlined />}
              />
            </Col>
            <Col span={12}>
              <Statistic 
                title="Средний балл" 
                value={user.average_score} 
                precision={2}
                suffix="%"
                prefix={<StarOutlined />}
              />
            </Col>
          </Row>
          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={12}>
              <Statistic 
                title="Время обучения" 
                value={user.total_training_time} 
                suffix="мин."
                prefix={<ClockCircleOutlined />}
              />
            </Col>
            <Col span={12}>
              <Statistic 
                title="Табельный номер" 
                value={user.tabNumber}
                prefix={<TeamOutlined />}
              />
            </Col>
          </Row>
          <div style={{ marginTop: 16 }}>
            <Text strong>Роли:</Text>
            <div style={{ marginTop: 8 }}>
              {user.roles?.map((role, index) => (
                <Tag 
                  key={index} 
                  color={role === "ST-ADMIN" ? "red" : role === "ST" ? "blue" : "green"}
                  style={{ marginBottom: 4 }}
                >
                  {role}
                </Tag>
              ))}
            </div>
          </div>
          {user.description && (
            <div style={{ marginTop: 16 }}>
              <Text strong>Описание:</Text>
              <div style={{ marginTop: 8 }}>
                <Text type="secondary">{user.description}</Text>
              </div>
            </div>
          )}
          {user.last_course_completed && (
            <div style={{ marginTop: 16 }}>
              <Text strong>Последний пройденный курс:</Text>
              <div style={{ marginTop: 8 }}>
                <Text>{moment(user.last_course_completed).format("DD.MM.YYYY HH:mm")}</Text>
              </div>
            </div>
          )}
        </div>
      ),
      onOk() {},
    });
  };

  const handleDeleteUser = (user) => {
    setUserToDelete(user);
    setDeleteConfirmVisible(true);
  };

  const confirmDeleteUser = async () => {
    if (!userToDelete) return;
    
    try {
        setLoading(true);
        // Используем метод из store
        await securityTrainingStore.deleteSTUser(userToDelete.id);
        message.success("Пользователь успешно удален");
        await loadUsers();
    } catch (error) {
        message.error("Ошибка при удалении пользователя");
    } finally {
        setLoading(false);
        setDeleteConfirmVisible(false);
        setUserToDelete(null);
    }
};

  const handleModalSubmit = async () => {
    try {
        const values = await form.validateFields();
        
        // Для редактирования пароль не обязателен
        if (modalMode === "create" && values.password !== values.passwordConfirm) {
            message.error("Пароли не совпадают");
            return;
        }

        setLoading(true);
        
        // Подготавливаем данные
        const userData = {
            login: values.login.trim(),
            tabNumber: values.tabNumber.trim(),
            description: values.description?.trim() || '',
            roles: values.roles || ['ST'],
            completed_courses: values.completed_courses || 0,
            average_score: values.average_score || 0,
            total_training_time: values.total_training_time || 0,
        };
        
        if (modalMode === "create") {
            userData.password = values.password;
        } else if (modalMode === "edit" && values.password && values.password.trim()) {
            userData.password = values.password;
        }
        
        console.log('Submitting user data:', { modalMode, currentUser, userData });

        if (modalMode === "create") {
            try {
                await securityTrainingStore.createSTUser(userData);
                message.success("Пользователь успешно создан/обновлен");
            } catch (error) {
                if (error.response?.status === 400 && 
                    error.response?.data?.message?.includes('уже существует')) {
                    // Можно показать дополнительное сообщение
                    message.info("Пользователь был добавлен в систему обучения");
                } else {
                    throw error;
                }
            }
        } else if (modalMode === "edit" && currentUser) {
            await securityTrainingStore.updateSTUser(currentUser.id, userData);
            message.success("Пользователь успешно обновлен");
        }

        setModalVisible(false);
        form.resetFields();
        await loadUsers();
        
    } catch (error) {
        console.error("Ошибка при сохранении пользователя:", error);
        if (error.response?.data?.message) {
            message.error(error.response.data.message);
        } else if (error.message) {
            message.error(error.message);
        } else {
            message.error("Ошибка при сохранении пользователя");
        }
    } finally {
        setLoading(false);
    }
};


  const getRoleColor = (role) => {
    switch (role) {
      case "ADMIN":
        return "red";
      case "ST-ADMIN":
        return "volcano";
      case "ST":
        return "blue";
      case "USER":
        return "green";
      default:
        return "default";
    }
  };

  const getProgressColor = (score) => {
    if (score >= 80) return "success";
    if (score >= 60) return "normal";
    return "exception";
  };

  const userColumns = [
    {
      title: "Пользователь",
      dataIndex: "login",
      key: "login",
      width: 200,
      render: (text, record) => (
        <Space>
          <AvatarWithFallback
            tabNumber={record.tabNumber}
            size={45}
            fallbackSrc={`${process.env.REACT_APP_API_URL}static/photo/no.jpg`}
            timestamp={Date.now()}
          />
          <div>
            <Text strong style={{ fontSize: "14px" }}>{text || "Не указано"}</Text>
            <div>
              <Text type="secondary" style={{ fontSize: "12px" }}>
                {record.tabNumber}
              </Text>
            </div>
            <div>
              <Text type="secondary" style={{ fontSize: "12px" }}>
                {record.description}
              </Text>
            </div>
          </div>
        </Space>
      ),
    },
    {
      title: "Роли",
      dataIndex: "roles",
      key: "roles",
      width: 150,
      render: (roles) => (
        <Space wrap>
          {roles?.map((role, index) => (
            <Tag key={index} color={getRoleColor(role)}>
              {role}
            </Tag>
          ))}
        </Space>
      ),
    },
    {
      title: "Статистика обучения",
      key: "stats",
      width: 250,
      render: (_, record) => (
        <div>
          <Space direction="vertical" size={2} style={{ width: "100%" }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <Text type="secondary" style={{ fontSize: "12px" }}>
                Курсы:
              </Text>
              <Badge
                count={record.completed_courses || 0}
                style={{ backgroundColor: "#52c41a" }}
              />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <Text type="secondary" style={{ fontSize: "12px" }}>
                Средний балл:
              </Text>
              <Progress
                percent={record.average_score || 0}
                size="small"
                strokeColor={getProgressColor(record.average_score)}
                style={{ width: 100 }}
              />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <Text type="secondary" style={{ fontSize: "12px" }}>
                Время обучения:
              </Text>
              <Text style={{ fontSize: "12px" }}>
                {record.total_training_time || 0} мин.
              </Text>
            </div>
          </Space>
        </div>
      ),
    },
    {
      title: "Последняя активность",
      dataIndex: "last_course_completed",
      key: "lastActivity",
      width: 150,
      render: (date) => (
        <div>
          {date ? (
            <div>
              <Text style={{ fontSize: "12px" }}>
                {moment(date).format("DD.MM.YYYY")}
              </Text>
              <div>
                <Text type="secondary" style={{ fontSize: "11px" }}>
                  {moment(date).format("HH:mm")}
                </Text>
              </div>
            </div>
          ) : (
            <Tag color="default">Нет данных</Tag>
          )}
        </div>
      ),
    },
    {
      title: "Действия",
      key: "actions",
      width: 150,
      fixed: "right",
      render: (_, record) => (
        <Space>
          <Tooltip title="Просмотр">
            <Button
              size="small"
              icon={<EyeOutlined />}
              onClick={() => handleViewUser(record)}
            />
          </Tooltip>
          <Tooltip title="Редактировать">
            <Button
              size="small"
              icon={<EditOutlined />}
              onClick={() => handleEditUser(record)}
            />
          </Tooltip>
          <Tooltip title="Удалить">
            <Popconfirm
              title="Удалить пользователя?"
              description={`Вы уверены, что хотите удалить пользователя ${record.login}?`}
              onConfirm={() => handleDeleteUser(record)}
              okText="Да"
              cancelText="Нет"
            >
              <Button
                size="small"
                danger
                icon={<DeleteOutlined />}
              />
            </Popconfirm>
          </Tooltip>
        </Space>
      ),
    },
  ];

  const statsData = {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.last_course_completed && 
      moment(u.last_course_completed).isAfter(moment().subtract(7, 'days'))).length,
    avgScore: users.length > 0 
      ? (users.reduce((sum, user) => sum + (user.average_score || 0), 0) / users.length).toFixed(1)
      : 0,
    totalCourses: users.reduce((sum, user) => sum + (user.completed_courses || 0), 0),
  };

  return (
    <Space direction="vertical" style={{ width: "100%" }} size="large">
      

      {/* Статистика */}
      <Row gutter={16}>
        <Col span={6}>
          <Card>
            <Statistic
              title="Всего пользователей"
              value={statsData.totalUsers}
              prefix={<TeamOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="Активных (7 дней)"
              value={statsData.activeUsers}
              prefix={<UserAddOutlined />}
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="Средний балл"
              value={statsData.avgScore}
              suffix="%"
              prefix={<StarOutlined />}
              valueStyle={{ color: '#fa8c16' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="Всего пройдено курсов"
              value={statsData.totalCourses}
              prefix={<BookOutlined />}
              valueStyle={{ color: '#722ed1' }}
            />
          </Card>
        </Col>
      </Row>

      {/* Панель управления */}
      <Card>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 16,
          }}
        >
          <Title level={5} style={{ margin: 0 }}>
            Пользователи обучения ({users.length})
          </Title>
          <Space>
            <Button 
              icon={<PlusOutlined />} 
              type="primary"
              onClick={handleCreateUser}
              loading={loading}
            >
              Добавить пользователя
            </Button>
            <Button 
              icon={<DownloadOutlined />}
              onClick={() => message.info("Экспорт данных в разработке")}
            >
              Экспорт
            </Button>
          </Space>
        </div>

        <Table
          columns={userColumns}
          dataSource={users}
          loading={loading}
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `Всего ${total} пользователей`,
          }}
          rowKey={(record) => record.id || record.tabNumber}
          scroll={{ x: 1000 }}
          bordered
        />
      </Card>

      {/* Модальное окно создания/редактирования пользователя */}
      <Modal
        title={modalMode === "create" ? "Создание пользователя" : "Редактирование пользователя"}
        open={modalVisible}
        onOk={handleModalSubmit}
        onCancel={() => setModalVisible(false)}
        width={700}
        confirmLoading={loading}
        okText={modalMode === "create" ? "Создать" : "Сохранить"}
        cancelText="Отмена"
      >
        <Form
          form={form}
          layout="vertical"
          initialValues={{
            roles: ["ST"],
            completed_courses: 0,
            average_score: 0,
            total_training_time: 0,
          }}
        >
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                label="Логин"
                name="login"
                rules={[
                  { required: true, message: "Введите логин пользователя" },
                  { min: 3, message: "Логин должен содержать минимум 3 символа" },
                ]}
              >
                <Input placeholder="Введите логин" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label="Табельный номер"
                name="tabNumber"
                rules={[
                  { required: true, message: "Введите табельный номер" },
                ]}
              >
                <Input placeholder="Введите табельный номер" />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            label="Описание"
            name="description"
          >
            <TextArea 
              rows={2} 
              placeholder="Введите описание пользователя" 
            />
          </Form.Item>

          <Form.Item
            label="Роли"
            name="roles"
            rules={[{ required: true, message: "Выберите роли пользователя" }]}
          >
            <Select
              mode="multiple"
              placeholder="Выберите роли"
              allowClear
            >
              <Option value="ST">ST (Обучающийся)</Option>
              <Option value="ST-ADMIN">ST-ADMIN (Администратор обучения)</Option>
           </Select>
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                label="Пароль"
                name="password"
                rules={[
                  { required: modalMode === "create", message: "Введите пароль" },
                  { min: 6, message: "Пароль должен содержать минимум 6 символов" },
                ]}
              >
                <Input.Password placeholder="Введите пароль" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label="Подтверждение пароля"
                name="passwordConfirm"
                rules={[
                  { required: modalMode === "create", message: "Подтвердите пароль" },
                ]}
              >
                <Input.Password placeholder="Подтвердите пароль" />
              </Form.Item>
            </Col>
          </Row>

          <Title level={5} style={{ marginTop: 24, marginBottom: 16 }}>
            Статистика обучения
          </Title>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item
                label="Пройдено курсов"
                name="completed_courses"
              >
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }} 
                  placeholder="Количество курсов" 
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label="Средний балл"
                name="average_score"
              >
                <InputNumber
                  min={0}
                  max={100}
                  style={{ width: "100%" }}
                  placeholder="Средний балл"
                  formatter={(value) => `${value}%`}
                  parser={(value) => value.replace('%', '')}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                label="Время обучения (мин.)"
                name="total_training_time"
              >
                <InputNumber 
                  min={0} 
                  style={{ width: "100%" }} 
                  placeholder="Время в минутах" 
                />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>

      {/* Модальное окно подтверждения удаления */}
      <Modal
        title="Подтверждение удаления"
        open={deleteConfirmVisible}
        onOk={confirmDeleteUser}
        onCancel={() => setDeleteConfirmVisible(false)}
        confirmLoading={loading}
        okText="Удалить"
        cancelText="Отмена"
        okType="danger"
      >
        {userToDelete && (
          <Space direction="vertical" style={{ width: "100%" }}>
            <Alert
              message="Внимание!"
              description={`При удалении пользователя ${userToDelete.login} будут удалены все связанные данные, включая прогресс обучения и статистику.`}
              type="warning"
              showIcon
            />
            <div style={{ marginTop: 16 }}>
              <Text strong>Пользователь:</Text>
              <div style={{ marginTop: 8 }}>
                <Space>
                  <AvatarWithFallback
                    tabNumber={userToDelete.tabNumber}
                    size={32}
                    fallbackSrc={`${process.env.REACT_APP_API_URL}static/photo/no.jpg`}
                  />
                  <div>
                    <Text strong>{userToDelete.login}</Text>
                    <div>
                      <Text type="secondary">{userToDelete.tabNumber}</Text>
                    </div>
                  </div>
                </Space>
              </div>
            </div>
            <div style={{ marginTop: 16 }}>
              <Text type="secondary">
                Это действие нельзя отменить. Вы уверены, что хотите продолжить?
              </Text>
            </div>
          </Space>
        )}
      </Modal>
    </Space>
  );
});

export default UsersContent;