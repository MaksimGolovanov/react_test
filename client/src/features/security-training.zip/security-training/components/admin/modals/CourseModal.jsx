// src/features/security-training/components/admin/modals/CourseModal.jsx
import React, { useState, useEffect } from 'react';
import {
  Modal,
  Steps,
  Form,
  Input,
  Select,
  Switch,
  Row,
  Col,
  Space,
  Button,
  Table,
  Tag,
  InputNumber,
  Upload,
  message,
  Typography,
  Divider,
  Card,
  Tabs,
  Radio,
  Checkbox,
  Tooltip
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  UploadOutlined,
  EyeOutlined,
  DragOutlined,
  ArrowUpOutlined,
  ArrowDownOutlined,
  SaveOutlined
} from '@ant-design/icons';
import CourseService from '../../../services/CourseService';

const { Step } = Steps;
const { Option } = Select;
const { TextArea } = Input;
const { TabPane } = Tabs;
const { Text } = Typography;

const CourseModal = ({
  visible,
  editingCourse,
  lessons,
  questions,
  currentStep,
  onClose,
  onStepChange,
  onLessonsChange,
  onQuestionsChange,
  onSubmit,
  onReloadLessons,
  onReloadQuestions,
  onCourseSaved,
}) => {
  const [form] = Form.useForm();
  const [lessonForm] = Form.useForm();
  const [questionForm] = Form.useForm();
  const [editingLesson, setEditingLesson] = useState(null);
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [options, setOptions] = useState([{ id: 'a', text: '', correct: false }]);
  const [questionType, setQuestionType] = useState('single');
  const [lessonModalVisible, setLessonModalVisible] = useState(false);
const [questionModalVisible, setQuestionModalVisible] = useState(false);
const [savingLesson, setSavingLesson] = useState(false);
const [savingQuestion, setSavingQuestion] = useState(false);
const [savingCourse, setSavingCourse] = useState(false);

  // Инициализация формы при редактировании
useEffect(() => {
    if (visible && currentStep === 0) {
        // Если редактируем существующий курс
        if (editingCourse) {
            form.setFieldsValue({
                title: editingCourse.title || '',
                description: editingCourse.description || '',
                short_description: editingCourse.short_description || '',
                level: editingCourse.level || 'beginner',
                category: editingCourse.category || 'basics',
                duration: editingCourse.duration || '',
                duration_minutes: editingCourse.duration_minutes || 0,
                passing_score: editingCourse.passing_score || 70,
                attempts_limit: editingCourse.attempts_limit || 3,
                certification_available: editingCourse.certification_available || false,
                is_active: editingCourse.is_active !== undefined ? editingCourse.is_active : true,
                order_index: editingCourse.order_index || 0,
                tags: editingCourse.tags || []
            });
        } else {
            // Если новый курс - сбрасываем значения
            form.resetFields();
            form.setFieldsValue({
                level: 'beginner',
                category: 'basics',
                passing_score: 70,
                attempts_limit: 3,
                certification_available: false,
                is_active: true,
                order_index: 0,
                tags: []
            });
        }
    }
}, [visible, currentStep, editingCourse, form]);

  // Обработка создания/обновления курса
const handleSubmit = async () => {
  try {
    setSavingCourse(true);
    const values = await form.validateFields();
    
    console.log('Submitting course:', values);
    
    let result;
    if (editingCourse && editingCourse.id) {
      result = await CourseService.updateCourse(editingCourse.id, values);
      message.success('Курс успешно обновлен');
    } else {
      result = await CourseService.createCourse(values);
      message.success('Курс успешно создан');
      
      // Если это новый курс, вызываем callback
      if (onCourseSaved && result && result.course) {
        onCourseSaved(result);
      }
    }
    
    console.log('Course save result:', result);
    
    // Не закрываем модалку сразу, если мы на шаге уроков или вопросов
    
    
  } catch (error) {
    console.error('Error submitting course:', error);
    message.error('Ошибка сохранения курса: ' + (error.response?.data?.message || error.message));
    throw error;
  } finally {
    setSavingCourse(false);
  }
};

  // Управление уроками
  const handleAddLesson = () => {
    setEditingLesson(null);
    lessonForm.resetFields();
    setLessonModalVisible(true);
  };

 const handleEditLesson = (lesson) => {
  if (!lesson) {
    console.error('Lesson is null or undefined');
    return;
  }
  
  console.log('Editing lesson:', lesson);
  setEditingLesson(lesson);
  
  lessonForm.setFieldsValue({
    title: lesson.title || '',
    content: lesson.content || '',
    content_type: lesson.content_type || 'text',
    video_url: lesson.video_url || '',
    presentation_url: lesson.presentation_url || '',
    duration: lesson.duration || 0,
    order_index: lesson.order_index || 0,
    is_active: lesson.is_active !== undefined ? lesson.is_active : true,
    additional_resources: lesson.additional_resources || []
  });
  
  setLessonModalVisible(true);
};

  const handleDeleteLesson = async (lessonId) => {
  try {
    if (!editingCourse || !editingCourse.id) {
      message.error('Курс не выбран');
      return;
    }
    
    Modal.confirm({
      title: 'Удалить урок?',
      content: 'Это действие нельзя отменить. Все данные урока будут удалены.',
      okText: 'Удалить',
      okType: 'danger',
      cancelText: 'Отмена',
      onOk: async () => {
        try {
          await CourseService.deleteLesson(editingCourse.id, lessonId);
          message.success('Урок успешно удален');
          
          // Обновляем список уроков
          if (onReloadLessons) {
            const updatedLessons = await onReloadLessons();
            onLessonsChange(updatedLessons);
          }
        } catch (error) {
          console.error('Error deleting lesson:', error);
          message.error('Ошибка при удалении урока');
        }
      }
    });
  } catch (error) {
    console.error('Error in delete confirmation:', error);
    message.error('Ошибка при подтверждении удаления');
  }
};

  const handleSaveLesson = async () => {
    try {
        setSavingLesson(true);
        const values = await lessonForm.validateFields();
        
        console.log('Saving lesson - editingCourse:', editingCourse);
        console.log('Lesson values:', values);
        
        // Проверяем, есть ли курс
        if (!editingCourse || !editingCourse.id) {
            message.warning('Сначала сохраните курс на первом шаге');
            onStepChange(0); // Переходим на шаг курса
            return;
        }
        
        // Сохраняем урок
        let result;
        if (editingLesson && editingLesson.id) {
            result = await CourseService.updateLesson(editingCourse.id, editingLesson.id, values);
            message.success('Урок успешно обновлен');
        } else {
            result = await CourseService.createLesson(editingCourse.id, values);
            message.success('Урок успешно создан');
        }
        
        console.log('Lesson saved:', result);
        
        // Закрываем модальное окно урока
        setLessonModalVisible(false);
        setEditingLesson(null);
        lessonForm.resetFields();
        
        // Обновляем список уроков
        if (onReloadLessons) {
            try {
                const updatedLessons = await CourseService.getCourseLessons(editingCourse.id);
                onLessonsChange(updatedLessons);
            } catch (reloadError) {
                console.error('Error reloading lessons:', reloadError);
            }
        }
        
    } catch (error) {
        console.error('Error saving lesson:', error);
        message.error('Ошибка сохранения урока: ' + (error.response?.data?.message || error.message));
    } finally {
        setSavingLesson(false);
    }
};
  // Управление вопросами
  const handleAddQuestion = () => {
    setEditingQuestion(null);
    setOptions([{ id: 'a', text: '', correct: false }]);
    setQuestionType('single');
    questionForm.resetFields();
    setQuestionModalVisible(true);
  };

  const handleEditQuestion = (question) => {
    setEditingQuestion(question);
    setOptions(question.options || [{ id: 'a', text: '', correct: false }]);
    setQuestionType(question.question_type);
    questionForm.setFieldsValue({
      question_text: question.question_text,
      question_type: question.question_type,
      explanation: question.explanation,
      points: question.points,
      order_index: question.order_index,
      is_active: question.is_active,
      correct_answer: question.correct_answer
    });
    setQuestionModalVisible(true);
  };

  const handleDeleteQuestion = async (questionId) => {
    try {
      if (editingCourse) {
        await CourseService.deleteQuestion(editingCourse.id, questionId);
        message.success('Вопрос удален');
        if (onReloadQuestions) {
          const updatedQuestions = await onReloadQuestions();
          onQuestionsChange(updatedQuestions);
        }
      }
    } catch (error) {
      console.error('Error deleting question:', error);
      message.error('Ошибка удаления вопроса');
    }
  };

  const handleAddOption = () => {
    const nextId = String.fromCharCode(97 + options.length); // a, b, c...
    setOptions([...options, { id: nextId, text: '', correct: false }]);
  };

  const handleUpdateOption = (index, field, value) => {
    const newOptions = [...options];
    newOptions[index][field] = value;
    setOptions(newOptions);
  };

  const handleRemoveOption = (index) => {
    if (options.length > 1) {
      const newOptions = options.filter((_, i) => i !== index);
      setOptions(newOptions);
    }
  };

  const handleSaveQuestion = async () => {
    try {
      const values = await questionForm.validateFields();
      
      if (questionType !== 'text') {
        // Валидация options
        if (options.some(opt => !opt.text.trim())) {
          message.error('Все варианты ответа должны быть заполнены');
          return;
        }

        const correctOptions = options.filter(opt => opt.correct);
        if (questionType === 'single' && correctOptions.length !== 1) {
          message.error('Должен быть выбран ровно один правильный ответ');
          return;
        }

        if (questionType === 'multiple' && correctOptions.length < 1) {
          message.error('Должен быть выбран хотя бы один правильный ответ');
          return;
        }

        values.options = options;
      }

      if (editingCourse) {
        if (editingQuestion) {
          await CourseService.updateQuestion(editingCourse.id, editingQuestion.id, values);
          message.success('Вопрос обновлен');
        } else {
          await CourseService.createQuestion(editingCourse.id, values);
          message.success('Вопрос создан');
        }
        
        if (onReloadQuestions) {
          const updatedQuestions = await onReloadQuestions();
          onQuestionsChange(updatedQuestions);
        }
        
        setQuestionModalVisible(false);
      }
    } catch (error) {
      console.error('Error saving question:', error);
      message.error('Ошибка сохранения вопроса');
    }
  };

  const steps = [
    {
      title: "Основная информация",
      content: (
        <Form form={form} layout="vertical">
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="title"
                label="Название курса"
                rules={[{ required: true, message: "Введите название курса" }]}
              >
                <Input placeholder="Основы информационной безопасности" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="level"
                label="Уровень сложности"
                rules={[{ required: true, message: "Выберите уровень" }]}
              >
                <Select placeholder="Выберите уровень">
                  <Option value="beginner">Начальный</Option>
                  <Option value="intermediate">Средний</Option>
                  <Option value="advanced">Продвинутый</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="short_description"
            label="Краткое описание (до 500 символов)"
          >
            <TextArea
              rows={3}
              placeholder="Краткое описание курса для карточки..."
              maxLength={500}
              showCount
            />
          </Form.Item>

          <Form.Item
            name="description"
            label="Полное описание"
          >
            <TextArea
              rows={6}
              placeholder="Полное описание курса..."
            />
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="category"
                label="Категория"
                rules={[{ required: true, message: "Выберите категорию" }]}
              >
                <Select placeholder="Выберите категорию">
                  <Option value="basics">Основы</Option>
                  <Option value="phishing">Фишинг</Option>
                  <Option value="passwords">Пароли</Option>
                  <Option value="social_engineering">Социальная инженерия</Option>
                  <Option value="malware">Вредоносное ПО</Option>
                  <Option value="data_protection">Защита данных</Option>
                  <Option value="network_security">Сетевая безопасность</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="tags"
                label="Теги"
              >
                <Select
                  mode="tags"
                  placeholder="Добавьте теги..."
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item
                name="duration"
                label="Продолжительность (текст)"
              >
                <Input placeholder="2 часа" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                name="duration_minutes"
                label="Продолжительность (минуты)"
              >
                <InputNumber
                  min={0}
                  style={{ width: '100%' }}
                  placeholder="120"
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                name="order_index"
                label="Порядок отображения"
              >
                <InputNumber
                  min={0}
                  style={{ width: '100%' }}
                  placeholder="0"
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item
                name="passing_score"
                label="Проходной балл (%)"
              >
                <InputNumber
                  min={0}
                  max={100}
                  style={{ width: '100%' }}
                  placeholder="70"
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                name="attempts_limit"
                label="Лимит попыток"
              >
                <InputNumber
                  min={1}
                  style={{ width: '100%' }}
                  placeholder="3"
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                name="certification_available"
                label="Сертификация"
                valuePropName="checked"
              >
                <Switch />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="is_active"
            label="Активен"
            valuePropName="checked"
          >
            <Switch />
          </Form.Item>
        </Form>
      ),
    },
    {
      title: "Управление уроками",
      content: (
        <div>
          <Space direction="vertical" style={{ width: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h4>Уроки курса ({lessons.length})</h4>
              <Button 
                type="primary" 
                icon={<PlusOutlined />}
                onClick={handleAddLesson}
              >
                Добавить урок
              </Button>
            </div>

            {lessons.length === 0 ? (
              <Card>
                <Text type="secondary">Уроки не добавлены. Добавьте первый урок.</Text>
              </Card>
            ) : (
              <Table
                dataSource={lessons}
                columns={[
                  {
                    title: 'Название',
                    dataIndex: 'title',
                    key: 'title',
                    render: (text, record) => (
                      <Space direction="vertical" size={2}>
                        <Text strong>{text}</Text>
                        <Text type="secondary" style={{ fontSize: '12px' }}>
                          {record.content_type === 'video' ? 'Видео' : 
                           record.content_type === 'interactive' ? 'Интерактив' : 
                           record.content_type === 'presentation' ? 'Презентация' : 'Текст'}
                          {record.duration > 0 && ` • ${record.duration} мин.`}
                        </Text>
                      </Space>
                    )
                  },
                  {
                    title: 'Тип',
                    dataIndex: 'content_type',
                    key: 'type',
                    render: (type) => (
                      <Tag color={
                        type === 'video' ? 'blue' : 
                        type === 'interactive' ? 'green' : 
                        type === 'presentation' ? 'orange' : 'default'
                      }>
                        {type === 'video' ? 'Видео' : 
                         type === 'interactive' ? 'Интерактив' : 
                         type === 'presentation' ? 'Презентация' : 'Текст'}
                      </Tag>
                    )
                  },
                  {
                    title: 'Порядок',
                    dataIndex: 'order_index',
                    key: 'order',
                    width: 80
                  },
                  {
                    title: 'Статус',
                    dataIndex: 'is_active',
                    key: 'status',
                    render: (active) => (
                      <Tag color={active ? 'green' : 'red'}>
                        {active ? 'Активен' : 'Неактивен'}
                      </Tag>
                    )
                  },
                  {
                    title: 'Действия',
                    key: 'actions',
                    width: 120,
                    render: (_, record) => (
                      <Space>
                        <Tooltip title="Редактировать">
                          <Button
                            icon={<EditOutlined />}
                            size="small"
                            onClick={() => handleEditLesson(record)}
                          />
                        </Tooltip>
                        <Tooltip title="Удалить">
                          <Button
                            icon={<DeleteOutlined />}
                            size="small"
                            danger
                            onClick={() => handleDeleteLesson(record.id)}
                          />
                        </Tooltip>
                      </Space>
                    )
                  }
                ]}
                rowKey="id"
                pagination={false}
              />
            )}
          </Space>
        </div>
      ),
    },
    {
      title: "Тестирование",
      content: (
        <div>
          <Space direction="vertical" style={{ width: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h4>Вопросы теста ({questions.length})</h4>
              <Button 
                type="primary" 
                icon={<PlusOutlined />}
                onClick={handleAddQuestion}
              >
                Добавить вопрос
              </Button>
            </div>

            {questions.length === 0 ? (
              <Card>
                <Text type="secondary">Вопросы не добавлены. Добавьте первый вопрос теста.</Text>
              </Card>
            ) : (
              <Table
                dataSource={questions}
                columns={[
                  {
                    title: 'Вопрос',
                    dataIndex: 'question_text',
                    key: 'question',
                    render: (text, record) => (
                      <Space direction="vertical" size={2}>
                        <Text>{text.substring(0, 80)}...</Text>
                        <Text type="secondary" style={{ fontSize: '12px' }}>
                          {record.question_type === 'single' ? 'Одиночный выбор' : 
                           record.question_type === 'multiple' ? 'Множественный выбор' : 'Текстовый ответ'}
                          {record.points > 1 && ` • ${record.points} баллов`}
                        </Text>
                      </Space>
                    )
                  },
                  {
                    title: 'Тип',
                    dataIndex: 'question_type',
                    key: 'type',
                    render: (type) => (
                      <Tag color={
                        type === 'single' ? 'blue' : 
                        type === 'multiple' ? 'green' : 'orange'
                      }>
                        {type === 'single' ? 'Одиночный' : 
                         type === 'multiple' ? 'Множественный' : 'Текстовый'}
                      </Tag>
                    )
                  },
                  {
                    title: 'Баллы',
                    dataIndex: 'points',
                    key: 'points',
                    width: 80
                  },
                  {
                    title: 'Порядок',
                    dataIndex: 'order_index',
                    key: 'order',
                    width: 80
                  },
                  {
                    title: 'Действия',
                    key: 'actions',
                    width: 120,
                    render: (_, record) => (
                      <Space>
                        <Tooltip title="Редактировать">
                          <Button
                            icon={<EditOutlined />}
                            size="small"
                            onClick={() => handleEditQuestion(record)}
                          />
                        </Tooltip>
                        <Tooltip title="Удалить">
                          <Button
                            icon={<DeleteOutlined />}
                            size="small"
                            danger
                            onClick={() => handleDeleteQuestion(record.id)}
                          />
                        </Tooltip>
                      </Space>
                    )
                  }
                ]}
                rowKey="id"
                pagination={false}
              />
            )}
          </Space>
        </div>
      ),
    },
  ];

  return (
    <>
      <Modal
        title={editingCourse ? "Редактирование курса" : "Создание нового курса"}
        open={visible}
        onCancel={onClose}
        width={900}
        footer={[
          currentStep > 0 && (
            <Button key="back" onClick={() => onStepChange(currentStep - 1)}>
              Назад
            </Button>
          ),
          currentStep < steps.length - 1 ? (
            <Button key="next" type="primary" onClick={() => onStepChange(currentStep + 1)}>
              Далее
            </Button>
          ) : (
            <Button 
  key="submit" 
  type="primary" 
  onClick={handleSubmit}
  loading={savingCourse}
>
  {editingCourse ? "Сохранить изменения" : "Создать курс"}
</Button>
          )
        ]}
      >
        <Steps current={currentStep} style={{ marginBottom: '24px' }}>
          {steps.map((step, index) => (
            <Step key={index} title={step.title} />
          ))}
        </Steps>
        
        <div style={{ minHeight: '500px', maxHeight: '600px', overflowY: 'auto' }}>
          {steps[currentStep].content}
        </div>
      </Modal>

      {/* Модальное окно урока */}
      <Modal
  title={editingLesson ? "Редактирование урока" : "Создание урока"}
  open={lessonModalVisible}
  onCancel={() => {
    setLessonModalVisible(false);
    setEditingLesson(null);
    lessonForm.resetFields();
  }}
  width={700}
  footer={[
    <Button 
      key="cancel" 
      onClick={() => {
        setLessonModalVisible(false);
        setEditingLesson(null);
        lessonForm.resetFields();
      }}
    >
      Отмена
    </Button>,
    <Button 
      key="save" 
      type="primary" 
      onClick={handleSaveLesson}
      loading={savingLesson}
      icon={<SaveOutlined />}
    >
      Сохранить
    </Button>
  ]}
>
        <Form form={lessonForm} layout="vertical">
          <Form.Item
            name="title"
            label="Название урока"
            rules={[{ required: true, message: "Введите название урока" }]}
          >
            <Input placeholder="Введение в информационную безопасность" />
          </Form.Item>

          <Form.Item
            name="content_type"
            label="Тип контента"
            rules={[{ required: true, message: "Выберите тип контента" }]}
          >
            <Select placeholder="Выберите тип контента">
              <Option value="text">Текстовый урок</Option>
              <Option value="video">Видеоурок</Option>
              <Option value="presentation">Презентация</Option>
              <Option value="interactive">Интерактивный урок</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="content"
            label="Содержание урока"
            rules={[{ required: true, message: "Введите содержание урока" }]}
          >
            <TextArea
              rows={8}
              placeholder="HTML или Markdown содержимое урока..."
            />
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="video_url"
                label="URL видео (если применимо)"
              >
                <Input placeholder="https://youtube.com/..." />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="presentation_url"
                label="URL презентации (если применимо)"
              >
                <Input placeholder="https://docs.google.com/..." />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="duration"
                label="Длительность (минуты)"
              >
                <InputNumber
                  min={0}
                  style={{ width: '100%' }}
                  placeholder="15"
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="order_index"
                label="Порядок в курсе"
              >
                <InputNumber
                  min={0}
                  style={{ width: '100%' }}
                  placeholder="0"
                />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="is_active"
            label="Активен"
            valuePropName="checked"
          >
            <Switch />
          </Form.Item>
        </Form>
      </Modal>

      {/* Модальное окно вопроса */}
      <Modal
        title={editingQuestion ? "Редактирование вопроса" : "Создание вопроса"}
        open={questionModalVisible}
        onCancel={() => setQuestionModalVisible(false)}
        onOk={handleSaveQuestion}
        width={700}
        okText="Сохранить"
        cancelText="Отмена"
      >
        <Form form={questionForm} layout="vertical">
          <Form.Item
            name="question_text"
            label="Текст вопроса"
            rules={[{ required: true, message: "Введите текст вопроса" }]}
          >
            <TextArea
              rows={3}
              placeholder="Что такое фишинг?"
            />
          </Form.Item>

          <Form.Item
            name="question_type"
            label="Тип вопроса"
            rules={[{ required: true, message: "Выберите тип вопроса" }]}
          >
            <Select 
              placeholder="Выберите тип вопроса"
              onChange={(value) => setQuestionType(value)}
            >
              <Option value="single">Одиночный выбор</Option>
              <Option value="multiple">Множественный выбор</Option>
              <Option value="text">Текстовый ответ</Option>
            </Select>
          </Form.Item>

          {questionType !== 'text' && (
            <>
              <Divider orientation="left">Варианты ответа</Divider>
              {options.map((option, index) => (
                <Card 
                  key={option.id} 
                  size="small" 
                  style={{ marginBottom: 8 }}
                  extra={
                    options.length > 1 && (
                      <Button
                        type="text"
                        danger
                        size="small"
                        onClick={() => handleRemoveOption(index)}
                      >
                        Удалить
                      </Button>
                    )
                  }
                >
                  <Row gutter={8} align="middle">
                    <Col span={2}>
                      <Tag>{option.id.toUpperCase()}</Tag>
                    </Col>
                    <Col span={18}>
                      <Input
                        value={option.text}
                        onChange={(e) => handleUpdateOption(index, 'text', e.target.value)}
                        placeholder="Текст варианта ответа"
                      />
                    </Col>
                    <Col span={4}>
                      {questionType === 'single' ? (
                        <Radio
                          checked={option.correct}
                          onChange={(e) => {
                            const newOptions = options.map((opt, i) => ({
                              ...opt,
                              correct: i === index ? e.target.checked : false
                            }));
                            setOptions(newOptions);
                          }}
                        >
                          Верный
                        </Radio>
                      ) : (
                        <Checkbox
                          checked={option.correct}
                          onChange={(e) => handleUpdateOption(index, 'correct', e.target.checked)}
                        >
                          Верный
                        </Checkbox>
                      )}
                    </Col>
                  </Row>
                </Card>
              ))}
              
              <Button
                type="dashed"
                onClick={handleAddOption}
                block
                icon={<PlusOutlined />}
              >
                Добавить вариант
              </Button>
            </>
          )}

          {questionType === 'text' && (
            <Form.Item
              name="correct_answer"
              label="Правильный ответ"
              rules={[{ required: true, message: "Введите правильный ответ" }]}
            >
              <Input placeholder="Правильный ответ на вопрос" />
            </Form.Item>
          )}

          <Form.Item
            name="explanation"
            label="Объяснение (после ответа)"
          >
            <TextArea
              rows={3}
              placeholder="Объяснение правильного ответа..."
            />
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="points"
                label="Баллы за вопрос"
              >
                <InputNumber
                  min={1}
                  style={{ width: '100%' }}
                  placeholder="1"
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="order_index"
                label="Порядок в тесте"
              >
                <InputNumber
                  min={0}
                  style={{ width: '100%' }}
                  placeholder="0"
                />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="is_active"
            label="Активен"
            valuePropName="checked"
          >
            <Switch />
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
};

export default CourseModal;