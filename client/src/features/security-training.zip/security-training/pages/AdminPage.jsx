// src/features/security-training/pages/AdminPage.jsx
import React, { useState, useEffect } from "react";
import { observer } from "mobx-react-lite";
import { Modal, message } from "antd";
import trainingStore from "../store/SecurityTrainingStore";
import { courses } from "../data/coursesData";
import { toJS } from "mobx";

// Импорт компонентов
import MainLayout from "../components/admin/MainLayout";
import DashboardContent from "../components/admin/DashboardContent";
import UsersContent from "../components/admin/UsersContent";
import AnalyticsContent from "../components/admin/AnalyticsContent";
import CoursesContent from "../components/admin/CoursesContent";
import CourseModal from "../components/admin/modals/CourseModal";

const AdminPage = observer(() => {
  const [selectedMenu, setSelectedMenu] = useState("dashboard");
  const [isCourseModalVisible, setIsCourseModalVisible] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [lessons, setLessons] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    console.log("Store users:", trainingStore.users?.length || 0);
    // Используем безопасное получение данных
    const storeUsers = toJS(trainingStore.users);
    setUsers(Array.isArray(storeUsers) ? storeUsers : []);
  }, [trainingStore.users]);

  // Безопасная функция для получения статистики дашборда
  const getDashboardStats = () => {
    const totalUsers = users.length || 0;
    
    // Безопасно получаем userProgress
    let userProgressData;
    try {
      userProgressData = trainingStore.userProgress || {};
    } catch (error) {
      console.error("Error getting userProgress:", error);
      userProgressData = {};
    }
    
    // Безопасно получаем значения из userProgress
    let progressValues = [];
    try {
      progressValues = Object.values(userProgressData);
    } catch (error) {
      console.error("Error getting values from userProgress:", error);
      progressValues = [];
    }
    
    const totalCompletedCourses = progressValues.filter(
      (progress) => progress && progress.completed
    ).length || 0;
    
    const totalScore = progressValues.reduce((acc, progress) => {
      if (progress && typeof progress.testScore === 'number') {
        return acc + progress.testScore;
      }
      return acc;
    }, 0);
    
    const averageScore = totalUsers > 0 ? totalScore / totalUsers : 0;
    
    // Безопасно получаем курсы
    const coursesList = Array.isArray(courses) ? courses : [];
    const activeCourses = coursesList.filter((c) => c && c.active).length;

    return {
      totalUsers,
      totalCompletedCourses,
      averageScore: parseFloat(averageScore.toFixed(2)),
      activeCourses,
    };
  };

  // Используем безопасное получение статистики
  const dashboardStats = getDashboardStats();

  // Моковые данные для аналитики с проверками
  const analytics = {
    totalActiveUsers: 150,
    newUsersThisMonth: 15,
    completionRate: 68,
    avgTimeToComplete: "2.5 часа",
    popularCourses: [
      { id: 1, name: "Основы информационной безопасности", completions: 120 },
      { id: 2, name: "Защита от фишинга", completions: 85 },
      { id: 3, name: "Парольная безопасность", completions: 73 },
    ],
    monthlyStats: [
      { month: "Янв", completions: 45, score: 82 },
      { month: "Фев", completions: 52, score: 85 },
      { month: "Мар", completions: 48, score: 79 },
      { month: "Апр", completions: 61, score: 88 },
    ],
  };

  // Безопасные обработчики
  const handleEditCourse = (course) => {
    if (!course) return;
    
    setEditingCourse(course);
    setLessons(course.lessons || []);
    setQuestions(course.test?.questions || []);
    setCurrentStep(0);
    setIsCourseModalVisible(true);
  };

  const handleManageLessons = (course) => {
    if (!course) return;
    
    setEditingCourse(course);
    setLessons(course.lessons || []);
    setCurrentStep(1);
    setIsCourseModalVisible(true);
  };

  const handleManageTest = (course) => {
    if (!course) return;
    
    setEditingCourse(course);
    setQuestions(course.test?.questions || []);
    setCurrentStep(2);
    setIsCourseModalVisible(true);
  };

  const handlePreviewCourse = (course) => {
    if (!course) return;
    
    Modal.info({
      title: course.title || "Курс",
      width: 800,
      content: (
        <div>
          <p>
            <strong>Описание:</strong> {course.description || "Нет описания"}
          </p>
          <p>
            <strong>Уровень:</strong> {course.level || "Не указан"}
          </p>
          <p>
            <strong>Продолжительность:</strong> {course.duration || "Не указана"}
          </p>
          <p>
            <strong>Уроки:</strong> {(course.lessons?.length || 0)}
          </p>
          <p>
            <strong>Тестовые вопросы:</strong>{" "}
            {(course.test?.questions?.length || 0)}
          </p>
        </div>
      ),
    });
  };

  const handleDeleteCourse = (courseId) => {
    Modal.confirm({
      title: "Удалить курс?",
      content: "Все данные о прохождении этого курса также будут удалены.",
      okText: "Удалить",
      okType: "danger",
      cancelText: "Отмена",
      onOk: () => {
        message.success("Курс удален");
      },
    });
  };

  const handleAddCourse = () => {
    setEditingCourse(null);
    setLessons([]);
    setQuestions([]);
    setCurrentStep(0);
    setIsCourseModalVisible(true);
  };

  const handleMenuSelect = (key) => {
    setSelectedMenu(key);
  };

  // Безопасный рендер контента
  const renderContent = () => {
    try {
      switch (selectedMenu) {
        case "dashboard":
          return (
            <DashboardContent
              stats={dashboardStats}
              onNavigate={setSelectedMenu}
              analytics={analytics}
            />
          );
        case "courses":
          const coursesList = Array.isArray(courses) ? courses : [];
          return (
            <CoursesContent
              courses={coursesList}
              onEditCourse={handleEditCourse}
              onPreviewCourse={handlePreviewCourse}
              onManageLessons={handleManageLessons}
              onManageTest={handleManageTest}
              onDeleteCourse={handleDeleteCourse}
            />
          );
        case "users":
          return <UsersContent users={users} loading={loading} />;
        case "analytics":
          return <AnalyticsContent analytics={analytics} />;
        default:
          return (
            <DashboardContent
              stats={dashboardStats}
              onNavigate={setSelectedMenu}
              analytics={analytics}
            />
          );
      }
    } catch (error) {
      console.error("Error rendering content:", error);
      return (
        <div style={{ padding: 24 }}>
          <p>Произошла ошибка при загрузке контента. Пожалуйста, обновите страницу.</p>
        </div>
      );
    }
  };

  // Добавим безопасный доступ к store
  const storeCourses = Array.isArray(courses) ? courses : [];

  return (
    <>
      <MainLayout
        selectedMenu={selectedMenu}
        onMenuSelect={handleMenuSelect}
        onAddCourse={handleAddCourse}
        showAddCourseButton={selectedMenu === "courses"}
      >
        {renderContent()}
      </MainLayout>

      {/* Модальные окна */}
      <CourseModal
        visible={isCourseModalVisible}
        editingCourse={editingCourse}
        lessons={lessons}
        questions={questions}
        currentStep={currentStep}
        onClose={() => {
          setIsCourseModalVisible(false);
          setEditingCourse(null);
          setLessons([]);
          setQuestions([]);
          setCurrentStep(0);
        }}
        onStepChange={setCurrentStep}
        onLessonsChange={setLessons}
        onQuestionsChange={setQuestions}
      />
    </>
  );
});

export default AdminPage;