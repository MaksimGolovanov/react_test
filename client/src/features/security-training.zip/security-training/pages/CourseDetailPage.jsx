import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Layout,
  Menu,
  Card,
  Button,
  Typography,
  Steps,
  Tag,
  Alert,
  Row,
  Col,
  Divider,
  Modal,
  Progress,
  Space,
  Spin
} from 'antd';
import {
  PlayCircleOutlined,
  CheckCircleOutlined,
  FileTextOutlined,
  ArrowLeftOutlined,
  SafetyCertificateOutlined,
  ClockCircleOutlined
} from '@ant-design/icons';
import { observer } from 'mobx-react-lite';
import trainingStore from '../store/SecurityTrainingStore';
import CourseService from '../services/CourseService'; // Добавьте этот импорт
import userStore from '../../admin/store/UserStore'; // Импортируем store пользователя

const { Header, Content, Sider } = Layout;
const { Title, Text, Paragraph } = Typography;
const { Step } = Steps;

const CourseDetailPage = observer(() => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [course, setCourse] = useState(null);
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userProgress, setUserProgress] = useState(null);

  const isUserAuthenticated = userStore.isAuthenticated;
  const tabNumber = userStore.tabNumber || '';

  useEffect(() => {
    loadCourseData();
  }, [courseId]);

  const loadCourseData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Загружаем курс
      const courseData = await CourseService.getCourseById(courseId);
      setCourse(courseData);
      
      // Загружаем уроки
      const lessonsData = await CourseService.getCourseLessons(courseId);
      setLessons(lessonsData || []);
      
      // Загружаем прогресс пользователя
      if (isUserAuthenticated && tabNumber) {
        try {
          const progressData = await CourseService.getUserProgress(tabNumber, courseId);
          if (progressData) {
            setUserProgress({
              completedLessons: progressData.completed_lessons || [],
              testScore: progressData.test_score || 0,
              passed_test: progressData.passed_test || false,
              totalTimeSpent: progressData.total_time_spent || 0,
              completed: progressData.passed_test || false
            });
          }
        } catch (progressError) {
          console.error('Error loading progress:', progressError);
          // Используем данные из store
          const storeProgress = trainingStore.userProgress[courseId];
          setUserProgress(storeProgress || {
            completedLessons: [],
            testScore: 0,
            passed_test: false,
            totalTimeSpent: 0,
            completed: false
          });
        }
      } else {
        // Используем данные из store для неавторизованных пользователей
        const storeProgress = trainingStore.userProgress[courseId];
        setUserProgress(storeProgress || {
          completedLessons: [],
          testScore: 0,
          passed_test: false,
          totalTimeSpent: 0,
          completed: false
        });
      }
      
      // Если есть уроки, выбираем первый
      if (lessonsData && lessonsData.length > 0) {
        setSelectedLesson(lessonsData[0]);
      }
      
    } catch (error) {
      console.error('Error loading course data:', error);
      setError('Не удалось загрузить данные курса');
    } finally {
      setLoading(false);
    }
  };

  // Используем прогресс из trainingStore
  const progress = userProgress || trainingStore.userProgress[courseId] || {
    completedLessons: [],
    testScore: 0,
    completed: false,
    completionDate: null,
    totalTimeSpent: 0
  };

  const isCourseCompleted = progress.completed || false;
  const canTakeTest = trainingStore.canTakeTest(courseId, lessons.length || 0);

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Spin size="large" tip="Загрузка курса..." />
      </div>
    );
  }

  if (error || !course) {
    return (
      <div style={{ padding: '50px', textAlign: 'center' }}>
        <Alert
          message="Курс не найден"
          description={error || "Запрошенный курс не существует или был удален"}
          type="error"
          showIcon
        />
        <Button 
          type="primary" 
          onClick={() => navigate('/security-training')}
          style={{ marginTop: '20px' }}
        >
          Вернуться к списку курсов
        </Button>
      </div>
    );
  }

  const handleCompleteLesson = (lessonId) => {
    trainingStore.completeLesson(courseId, lessonId);
  };

  const handleStartTest = () => {
    if (canTakeTest) {
      navigate(`/security-training/test/${courseId}`);
    } else {
      Modal.warning({
        title: 'Доступ к тесту ограничен',
        content: 'Для прохождения теста необходимо завершить все уроки курса.',
        okText: 'Понятно'
      });
    }
  };

  const getLessonStatus = (lessonId) => {
    if (!progress?.completedLessons) return 'pending';
    return progress.completedLessons.includes(lessonId) ? 'finish' : 'process';
  };

  const completedLessonsCount = progress?.completedLessons?.length || 0;
  const totalLessons = lessons.length || 0;
  const progressPercentage = totalLessons > 0 ? Math.round((completedLessonsCount / totalLessons) * 100) : 0;

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        width={300}
        style={{
          background: '#fff',
          borderRight: '1px solid #f0f0f0',
          padding: '16px'
        }}
      >
        <div style={{ marginBottom: '24px' }}>
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate('/security-training')}
            type="text"
            style={{ marginBottom: '16px' }}
          >
            Назад к курсам
          </Button>
          
          <Title level={4} style={{ marginBottom: '8px' }}>
            {course.title}
          </Title>
          
          {course.short_description && (
            <Paragraph type="secondary" style={{ fontSize: '14px', marginBottom: '16px' }}>
              {course.short_description}
            </Paragraph>
          )}
          
          <Space direction="vertical" style={{ width: '100%' }}>
            <div>
              <Text type="secondary">Прогресс:</Text>
              <Progress percent={progressPercentage} size="small" />
            </div>
            
            <Row gutter={8}>
              <Col>
                <Tag color="blue">
                  {completedLessonsCount}/{totalLessons} уроков
                </Tag>
              </Col>
              <Col>
                <Tag color={
                  course.level === 'beginner' ? 'green' : 
                  course.level === 'intermediate' ? 'orange' : 'red'
                }>
                  {course.level === 'beginner' ? 'Начальный' : 
                   course.level === 'intermediate' ? 'Средний' : 'Продвинутый'}
                </Tag>
              </Col>
              {course.duration && (
                <Col>
                  <Tag>
                    <ClockCircleOutlined /> {course.duration}
                  </Tag>
                </Col>
              )}
            </Row>
            
            {isCourseCompleted && (
              <Alert
                message="Курс пройден"
                description={`Результат теста: ${progress.testScore}%`}
                type="success"
                showIcon
                icon={<SafetyCertificateOutlined />}
              />
            )}
          </Space>
        </div>

        <Divider orientation="left">Уроки курса</Divider>
        
        {lessons.length === 0 ? (
          <Alert
            message="Уроки не добавлены"
            description="В этом курсе пока нет уроков"
            type="info"
            showIcon
          />
        ) : (
          <Menu
            mode="inline"
            selectedKeys={selectedLesson ? [selectedLesson.id] : []}
            style={{ borderRight: 0 }}
          >
            {lessons.map((lesson, index) => (
              <Menu.Item
                key={lesson.id}
                icon={
                  progress?.completedLessons?.includes(lesson.id) ? (
                    <CheckCircleOutlined style={{ color: '#52c41a' }} />
                  ) : (
                    <FileTextOutlined />
                  )
                }
                onClick={() => setSelectedLesson(lesson)}
                style={{ marginBottom: '8px' }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span>
                    Урок {index + 1}: {lesson.title}
                  </span>
                  {lesson.duration && (
                    <Tag size="small">{lesson.duration} мин.</Tag>
                  )}
                </div>
              </Menu.Item>
            ))}
          </Menu>
        )}

        {lessons.length > 0 && (
          <div style={{ marginTop: '24px', padding: '0 8px' }}>
            <Button
              type="primary"
              block
              size="large"
              onClick={handleStartTest}
              disabled={!canTakeTest && !isCourseCompleted}
            >
              {isCourseCompleted ? 'Пройти тест еще раз' : 'Пройти тест'}
            </Button>
            
            {!canTakeTest && !isCourseCompleted && (
              <Text type="secondary" style={{ display: 'block', marginTop: '8px', fontSize: '12px' }}>
                Для доступа к тесту необходимо завершить все уроки
              </Text>
            )}
          </div>
        )}
      </Sider>

      <Layout>
        <Header style={{ 
          background: '#fff', 
          padding: '0 24px', 
          borderBottom: '1px solid #f0f0f0',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <Title level={4} style={{ margin: 0 }}>
            {selectedLesson?.title || 'Выберите урок'}
          </Title>
          
          {selectedLesson && (
            <Space>
              {selectedLesson.duration && (
                <Tag icon={<PlayCircleOutlined />} color="blue">
                  {selectedLesson.duration} мин.
                </Tag>
              )}
              {progress?.completedLessons?.includes(selectedLesson.id) && (
                <Tag icon={<CheckCircleOutlined />} color="green">
                  Завершено
                </Tag>
              )}
            </Space>
          )}
        </Header>

        <Content style={{ padding: '24px', overflow: 'auto' }}>
          {selectedLesson ? (
            <div style={{ maxWidth: '800px', margin: '0 auto' }}>
              <Card>
                <div style={{ marginBottom: '24px' }}>
                  <Title level={4}>{selectedLesson.title}</Title>
                  {selectedLesson.content_type && (
                    <Tag color={
                      selectedLesson.content_type === 'video' ? 'red' :
                      selectedLesson.content_type === 'interactive' ? 'green' : 'blue'
                    }>
                      {selectedLesson.content_type === 'video' ? 'Видеоурок' :
                       selectedLesson.content_type === 'interactive' ? 'Интерактив' : 'Текстовый урок'}
                    </Tag>
                  )}
                </div>
                
                {selectedLesson.content ? (
                  <div 
                    dangerouslySetInnerHTML={{ __html: selectedLesson.content }}
                    style={{ 
                      lineHeight: '1.6',
                      fontSize: '16px'
                    }}
                  />
                ) : (
                  <Alert
                    message="Контент урока не загружен"
                    description="Содержание урока временно недоступно"
                    type="warning"
                    showIcon
                  />
                )}
                
                {selectedLesson.video_url && (
                  <div style={{ marginTop: '24px' }}>
                    <Alert
                      message="Видеоурок"
                      description={
                        <a href={selectedLesson.video_url} target="_blank" rel="noopener noreferrer">
                          Ссылка на видео
                        </a>
                      }
                      type="info"
                      showIcon
                    />
                  </div>
                )}
                
                {selectedLesson.presentation_url && (
                  <div style={{ marginTop: '16px' }}>
                    <Alert
                      message="Презентация"
                      description={
                        <a href={selectedLesson.presentation_url} target="_blank" rel="noopener noreferrer">
                          Ссылка на презентацию
                        </a>
                      }
                      type="info"
                      showIcon
                    />
                  </div>
                )}
              </Card>
              
              <div style={{ marginTop: '32px', textAlign: 'center' }}>
                <Button
                  type="primary"
                  size="large"
                  icon={<CheckCircleOutlined />}
                  onClick={() => handleCompleteLesson(selectedLesson.id)}
                  disabled={progress?.completedLessons?.includes(selectedLesson.id)}
                >
                  {progress?.completedLessons?.includes(selectedLesson.id)
                    ? 'Урок завершен'
                    : 'Завершить урок'}
                </Button>
              </div>
            </div>
          ) : (
            <Card style={{ textAlign: 'center', padding: '40px' }}>
              <FileTextOutlined style={{ fontSize: '48px', color: '#1890ff', marginBottom: '16px' }} />
              <Title level={4}>Выберите урок для начала обучения</Title>
              <Text type="secondary">
                Начните с первого урока, чтобы освоить материал курса
              </Text>
            </Card>
          )}
        </Content>
      </Layout>
    </Layout>
  );
});

export default CourseDetailPage;