// src/features/security-training/pages/CoursesPage.jsx
import React, { useState, useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import userStore from '../../admin/store/UserStore';
import { 
  Row, 
  Col, 
  Typography, 
  Divider, 
  Alert, 
  Card, 
  Tag, 
  Progress, 
  Button, 
  Empty,
  Tabs,
  Space,
  Skeleton
} from 'antd';
import { 
  BookOutlined, 
  ClockCircleOutlined, 
  TrophyOutlined,
  CheckCircleOutlined,
  PlayCircleOutlined,
  ReloadOutlined
} from '@ant-design/icons';
import trainingStore from '../store/SecurityTrainingStore';
import CourseService from '../services/CourseService';
import { useNavigate } from 'react-router-dom';

const { Title, Text } = Typography;
const { TabPane } = Tabs;

const CoursesPage = observer(() => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [userProgress, setUserProgress] = useState({});
  const [refreshKey, setRefreshKey] = useState(0);
  const navigate = useNavigate();

  const isUserAuthenticated = userStore.isAuthenticated;
  const tabNumber = userStore.tabNumber || '';

  useEffect(() => {
    loadData();
  }, [refreshKey, isUserAuthenticated, tabNumber]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Загружаем курсы
      const coursesResponse = await CourseService.getCourses({ active: true });
      const loadedCourses = coursesResponse.courses || [];
      setCourses(loadedCourses);
      
      console.log('Auth status:', {
        isUserAuthenticated,
        tabNumber,
        storeAuth: trainingStore.isUserAuthenticated
      });
      
      // Загружаем прогресс пользователя (если авторизован)
      if (isUserAuthenticated && tabNumber) {
        const progressMap = {};
        
        // Вариант 1: Использовать данные из store
        const storeProgress = trainingStore.userProgress;
        
        // Вариант 2: Загрузить прогресс из API
        for (const course of loadedCourses) {
          try {
            // Сначала пробуем получить из API
            const apiProgress = await CourseService.getUserProgress(tabNumber, course.id);
            
            if (apiProgress && typeof apiProgress === 'object') {
              progressMap[course.id] = {
                completed_lessons: apiProgress.completed_lessons || [],
                test_score: apiProgress.test_score || 0,
                passed_test: apiProgress.passed_test || false,
                total_time_spent: apiProgress.total_time_spent || 0
              };
            } else {
              // Используем данные из store
              const storeData = storeProgress[course.id];
              if (storeData) {
                progressMap[course.id] = {
                  completed_lessons: storeData.completedLessons || [],
                  test_score: storeData.testScore || 0,
                  passed_test: storeData.completed || storeData.passed_test || false,
                  total_time_spent: storeData.totalTimeSpent || 0
                };
              } else {
                progressMap[course.id] = {
                  completed_lessons: [],
                  test_score: 0,
                  passed_test: false,
                  total_time_spent: 0
                };
              }
            }
            
          } catch (error) {
            console.error(`Error loading progress for course ${course.id}:`, error);
            // Используем данные из store как fallback
            const storeData = storeProgress[course.id];
            progressMap[course.id] = storeData ? {
              completed_lessons: storeData.completedLessons || [],
              test_score: storeData.testScore || 0,
              passed_test: storeData.completed || false,
              total_time_spent: storeData.totalTimeSpent || 0
            } : {
              completed_lessons: [],
              test_score: 0,
              passed_test: false,
              total_time_spent: 0
            };
          }
        }
        
        setUserProgress(progressMap);
        console.log('Progress loaded:', progressMap);
      }
      
    } catch (error) {
      console.error('Error loading courses:', error);
    } finally {
      setLoading(false);
    }
  };

  const getLevelName = (level) => {
    switch (level) {
      case 'beginner': return 'Начальный';
      case 'intermediate': return 'Средний';
      case 'advanced': return 'Продвинутый';
      default: return level;
    }
  };

  const getLevelColor = (level) => {
    switch (level) {
      case 'beginner': return 'green';
      case 'intermediate': return 'orange';
      case 'advanced': return 'red';
      default: return 'default';
    }
  };

  const getCategoryName = (category) => {
    const categories = {
      'basics': 'Основы',
      'phishing': 'Фишинг',
      'passwords': 'Пароли',
      'social_engineering': 'Социальная инженерия',
      'malware': 'Вредоносное ПО',
      'data_protection': 'Защита данных',
      'network_security': 'Сетевая безопасность'
    };
    return categories[category] || category;
  };

  const getUserCourseProgress = (courseId) => {
    const progress = userProgress[courseId];
    
    if (!progress) {
      // Если нет в загруженных данных, проверяем store
      const storeProgress = trainingStore.userProgress[courseId];
      if (storeProgress) {
        return {
          completed_lessons: storeProgress.completedLessons || [],
          test_score: storeProgress.testScore || 0,
          passed_test: storeProgress.completed || false,
          total_time_spent: storeProgress.totalTimeSpent || 0
        };
      }
      return {
        completed_lessons: [],
        test_score: 0,
        passed_test: false,
        total_time_spent: 0
      };
    }
    
    return progress;
  };

  const getProgressPercentage = (courseId) => {
    const progress = getUserCourseProgress(courseId);
    const course = courses.find(c => c.id === courseId);
    if (!course || !course.lessons || course.lessons.length === 0) return 0;
    
    return Math.round((progress.completed_lessons?.length || 0) / course.lessons.length * 100);
  };

  const handleStartCourse = (courseId) => {
    navigate(`/security-training/${courseId}`);
  };

  const handleContinueCourse = (courseId) => {
    navigate(`/security-training/${courseId}`);
  };

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  // Функция для проверки курса в процессе
  const isCourseInProgress = (courseId) => {
    const progress = getUserCourseProgress(courseId);
    const course = courses.find(c => c.id === courseId);
    const totalLessons = course?.lessons?.length || 0;
    
    // Курс в процессе, если:
    // 1. Есть завершенные уроки
    // 2. Не все уроки завершены
    // 3. Тест не пройден
    const hasCompletedLessons = progress.completed_lessons?.length > 0;
    const allLessonsCompleted = progress.completed_lessons?.length >= totalLessons;
    const testPassed = progress.passed_test;
    
    return hasCompletedLessons && !allLessonsCompleted && !testPassed;
  };

  // Функция для проверки завершенного курса
  const isCourseCompleted = (courseId) => {
    const progress = getUserCourseProgress(courseId);
    // Курс завершен, если тест пройден
    return progress.passed_test === true;
  };

  // Функция для получения количества завершенных курсов
  const getCompletedCoursesCount = () => {
    return Object.keys(userProgress).filter(courseId => 
      userProgress[courseId]?.passed_test === true
    ).length;
  };

  if (loading && courses.length === 0) {
    return (
      <div style={{ padding: '24px' }}>
        <Title level={2}>Обучение по информационной безопасности</Title>
        <Divider />
        <Row gutter={[24, 24]}>
          {[1, 2, 3, 4].map(i => (
            <Col key={i} xs={24} sm={12} lg={8} xl={6}>
              <Card>
                <Skeleton active />
              </Card>
            </Col>
          ))}
        </Row>
      </div>
    );
  }

  if (courses.length === 0 && !loading) {
    return (
      <div style={{ padding: '24px' }}>
        <Title level={2}>Обучение по информационной безопасности</Title>
        <Divider />
        <Empty
          description="Курсы пока не добавлены"
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          style={{ marginTop: 50 }}
        />
      </div>
    );
  }

  const completedCourses = getCompletedCoursesCount();
  const totalCourses = courses.length;

  return (
    <div style={{ padding: '24px' }}>
      <Space style={{ marginBottom: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <Title level={2}>Обучение по информационной безопасности</Title>
          <Text type="secondary">
            Пройдите курсы для повышения осведомленности и защиты от киберугроз
          </Text>
        </div>
        <Button 
          icon={<ReloadOutlined />} 
          onClick={handleRefresh}
          loading={loading}
        >
          Обновить
        </Button>
      </Space>

      <Divider />

      {isUserAuthenticated ? (
        <Alert
          message="Ваш прогресс"
          description={`Вы завершили ${completedCourses} из ${totalCourses} курсов`}
          type="info"
          showIcon
          style={{ marginBottom: '24px' }}
        />
      ) : (
        <Alert
          message="Внимание"
          description="Для сохранения прогресса обучения необходимо авторизоваться"
          type="warning"
          showIcon
          style={{ marginBottom: '24px' }}
        />
      )}

      <Tabs defaultActiveKey="all">
        <TabPane tab="Все курсы" key="all">
          <Row gutter={[24, 24]}>
            {courses.map(course => {
              const progress = getUserCourseProgress(course.id);
              const progressPercent = getProgressPercentage(course.id);
              const isCompleted = isCourseCompleted(course.id); // Используем функцию
              const inProgress = isCourseInProgress(course.id); // Используем функцию
              
              return (
                <Col key={course.id} xs={24} sm={12} lg={8} xl={6}>
                  <Card
                    hoverable
                    cover={
                      course.cover_image ? (
                        <img
                          alt={course.title}
                          src={course.cover_image}
                          style={{ height: 140, objectFit: 'cover' }}
                        />
                      ) : (
                        <div style={{ 
                          height: 140, 
                          background: '#f0f2f5',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          <BookOutlined style={{ fontSize: 48, color: '#bfbfbf' }} />
                        </div>
                      )
                    }
                    actions={[
                      isCompleted ? (
                        <Button 
                          type="link" 
                          icon={<CheckCircleOutlined />}
                          onClick={() => handleStartCourse(course.id)}
                        >
                          Завершен
                        </Button>
                      ) : inProgress ? (
                        <Button 
                          type="primary" 
                          icon={<PlayCircleOutlined />}
                          onClick={() => handleContinueCourse(course.id)}
                        >
                          Продолжить
                        </Button>
                      ) : (
                        <Button 
                          type="primary" 
                          icon={<PlayCircleOutlined />}
                          onClick={() => handleStartCourse(course.id)}
                        >
                          Начать
                        </Button>
                      )
                    ]}
                  >
                    <Card.Meta
                      title={course.title}
                      description={
                        <div>
                          <Text type="secondary" style={{ fontSize: '12px' }}>
                            {course.short_description?.substring(0, 100)}...
                          </Text>
                          
                          <div style={{ marginTop: 12 }}>
                            <Tag color={getLevelColor(course.level)}>
                              {getLevelName(course.level)}
                            </Tag>
                            <Tag>{getCategoryName(course.category)}</Tag>
                          </div>
                          
                          <div style={{ marginTop: 12 }}>
                            <Space>
                              <ClockCircleOutlined />
                              <Text type="secondary">{course.duration || 'Не указано'}</Text>
                            </Space>
                          </div>
                          
                          {isUserAuthenticated && (
                            <div style={{ marginTop: 12 }}>
                              <Progress 
                                percent={progressPercent} 
                                size="small" 
                                status={isCompleted ? "success" : inProgress ? "active" : "normal"}
                              />
                              <div style={{ marginTop: 4, fontSize: '12px' }}>
                                {isCompleted ? (
                                  <Text type="success">
                                    <TrophyOutlined /> Балл: {progress.test_score}%
                                  </Text>
                                ) : inProgress ? (
                                  <Text type="warning">
                                    Пройдено: {progress.completed_lessons?.length || 0}/{course.lessons?.length || 0} уроков
                                  </Text>
                                ) : (
                                  <Text type="secondary">Не начато</Text>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      }
                    />
                  </Card>
                </Col>
              );
            })}
          </Row>
        </TabPane>
        
        <TabPane tab="В процессе" key="in-progress">
          <Row gutter={[24, 24]}>
            {courses.filter(course => isCourseInProgress(course.id)).map(course => {
              const progress = getUserCourseProgress(course.id);
              const progressPercent = getProgressPercentage(course.id);
              
              return (
                <Col key={course.id} xs={24} sm={12} lg={8} xl={6}>
                  <Card
                    hoverable
                    onClick={() => handleContinueCourse(course.id)}
                    cover={
                      course.cover_image ? (
                        <img
                          alt={course.title}
                          src={course.cover_image}
                          style={{ height: 140, objectFit: 'cover' }}
                        />
                      ) : (
                        <div style={{ 
                          height: 140, 
                          background: '#f0f2f5',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          <BookOutlined style={{ fontSize: 48, color: '#1890ff' }} />
                        </div>
                      )
                    }
                  >
                    <Card.Meta
                      title={course.title}
                      description={
                        <div>
                          <Progress 
                            percent={progressPercent} 
                            status="active"
                            style={{ marginTop: 8 }}
                          />
                          <Text type="secondary" style={{ fontSize: '12px', display: 'block', marginTop: 8 }}>
                            {course.short_description?.substring(0, 60)}...
                          </Text>
                          <div style={{ marginTop: 8 }}>
                            <Text type="secondary" style={{ fontSize: '12px' }}>
                              Завершено уроков: {progress.completed_lessons?.length || 0}/{course.lessons?.length || 0}
                            </Text>
                          </div>
                        </div>
                      }
                    />
                  </Card>
                </Col>
              );
            })}
            
            {courses.filter(course => isCourseInProgress(course.id)).length === 0 && (
              <Col span={24}>
                <Empty
                  description="Нет курсов в процессе обучения"
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                />
              </Col>
            )}
          </Row>
        </TabPane>
        
        <TabPane tab="Завершенные" key="completed">
          <Row gutter={[24, 24]}>
            {courses.filter(course => isCourseCompleted(course.id)).map(course => {
              const progress = getUserCourseProgress(course.id);
              
              return (
                <Col key={course.id} xs={24} sm={12} lg={8} xl={6}>
                  <Card
                    hoverable
                    onClick={() => handleStartCourse(course.id)} // Добавлен обработчик клика
                    cover={
                      course.cover_image ? (
                        <img
                          alt={course.title}
                          src={course.cover_image}
                          style={{ height: 140, objectFit: 'cover' }}
                        />
                      ) : (
                        <div style={{ 
                          height: 140, 
                          background: '#52c41a',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          <CheckCircleOutlined style={{ fontSize: 48, color: 'white' }} />
                        </div>
                      )
                    }
                  >
                    <Card.Meta
                      title={course.title}
                      description={
                        <div>
                          <Text type="success" strong>
                            <TrophyOutlined /> Балл: {progress.test_score}%
                          </Text>
                          <Text type="secondary" style={{ fontSize: '12px', display: 'block', marginTop: 8 }}>
                            {course.short_description?.substring(0, 60)}...
                          </Text>
                          <div style={{ marginTop: 8 }}>
                            <Text type="secondary" style={{ fontSize: '12px' }}>
                              Завершено: {progress.completed_lessons?.length || 0} уроков
                            </Text>
                          </div>
                        </div>
                      }
                    />
                  </Card>
                </Col>
              );
            })}
            
            {courses.filter(course => isCourseCompleted(course.id)).length === 0 && (
              <Col span={24}>
                <Empty
                  description="Нет завершенных курсов"
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                />
              </Col>
            )}
          </Row>
        </TabPane>
      </Tabs>
    </div>
  );
});

export default CoursesPage;