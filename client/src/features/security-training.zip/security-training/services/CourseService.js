// src/services/CourseService.js
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL;

class CourseService {
    // Основные операции с курсами
    static async getCourses(params = {}) {
        try {
            const response = await axios.get(`${API_URL}api/courses`, { params });
            return response.data;
        } catch (error) {
            console.error('Error getting courses:', error);
            throw error;
        }
    }

    static async getCourseById(id) {
        try {
            const response = await axios.get(`${API_URL}api/courses/${id}`);
            return response.data;
        } catch (error) {
            console.error('Error getting course:', error);
            throw error;
        }
    }

    static async createCourse(courseData) {
        console.log('Creating course with data:', courseData);
        try {
            const response = await axios.post(`${API_URL}api/courses`, courseData);
            return response.data;

        } catch (error) {
            console.error('Error creating course:', error);
            throw error;
        }
    }

    static async updateCourse(id, courseData) {
        try {
            const response = await axios.put(`${API_URL}api/courses/${id}`, courseData);
            return response.data;
        } catch (error) {
            console.error('Error updating course:', error);
            throw error;
        }
    }

    static async deleteCourse(id) {
        try {
            await axios.delete(`${API_URL}api/courses/${id}`);
        } catch (error) {
            console.error('Error deleting course:', error);
            throw error;
        }
    }

    // Уроки
    static async getCourseLessons(courseId) {
        try {
            const response = await axios.get(`${API_URL}api/courses/${courseId}/lessons`);
            return response.data;
        } catch (error) {
            console.error('Error getting lessons:', error);
            throw error;
        }
    }

    static async createLesson(courseId, lessonData) {
        try {
            const response = await axios.post(`${API_URL}api/courses/${courseId}/lessons`, lessonData);
            return response.data;
        } catch (error) {
            console.error('Error creating lesson:', error);
            throw error;
        }
    }

    static async updateLesson(courseId, lessonId, lessonData) {
        try {
            const response = await axios.put(`${API_URL}api/courses/${courseId}/lessons/${lessonId}`, lessonData);
            return response.data;
        } catch (error) {
            console.error('Error updating lesson:', error);
            throw error;
        }
    }

    static async deleteLesson(courseId, lessonId) {
        try {
            await axios.delete(`${API_URL}api/courses/${courseId}/lessons/${lessonId}`);
        } catch (error) {
            console.error('Error deleting lesson:', error);
            throw error;
        }
    }

    // Вопросы теста
    static async getCourseQuestions(courseId) {
        try {
            const response = await axios.get(`${API_URL}api/courses/${courseId}/questions`);
            return response.data;
        } catch (error) {
            console.error('Error getting questions:', error);
            throw error;
        }
    }

    static async createQuestion(courseId, questionData) {
        try {
            const response = await axios.post(`${API_URL}api/courses/${courseId}/questions`, questionData);
            return response.data;
        } catch (error) {
            console.error('Error creating question:', error);
            throw error;
        }
    }

    static async updateQuestion(courseId, questionId, questionData) {
        try {
            const response = await axios.put(`${API_URL}api/courses/${courseId}/questions/${questionId}`, questionData);
            return response.data;
        } catch (error) {
            console.error('Error updating question:', error);
            throw error;
        }
    }

    static async deleteQuestion(courseId, questionId) {
        try {
            await axios.delete(`${API_URL}api/courses/${courseId}/questions/${questionId}`);
        } catch (error) {
            console.error('Error deleting question:', error);
            throw error;
        }
    }

    // Статистика
    static async getCourseStats(courseId) {
        try {
            const response = await axios.get(`${API_URL}api/courses/${courseId}/stats`);
            return response.data;
        } catch (error) {
            console.error('Error getting course stats:', error);
            throw error;
        }
    }

    // Прогресс пользователя
    static async getUserProgress(userId, courseId) {
        try {
            const response = await axios.get(`${API_URL}api/courses/user-progress/${userId}/courses/${courseId}`);
            return response.data;
        } catch (error) {
            console.error('Error getting user progress:', error);
            // Возвращаем null вместо throw, чтобы не ломать приложение
            return null;
        }
    }

    static async updateUserProgress(userId, courseId, progressData) {
        try {
            const response = await axios.put(
                `${API_URL}api/courses/user-progress/${userId}/courses/${courseId}`,
                progressData
            );
            return response.data;
        } catch (error) {
            console.error('Error updating user progress:', error);
            // Возвращаем null вместо throw
            return null;
        }
    }

    // Тестирование - только один метод
    static async submitTest(userId, courseId, testData) {
        try {
            console.log('Submitting test:', { userId, courseId, testData });
            const response = await axios.post(
                `${API_URL}api/courses/${courseId}/submit-test/${userId}`,
                testData,
                {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            );
            return response.data;
        } catch (error) {
            console.error('Error submitting test:', {
                message: error.message,
                response: error.response?.data,
                status: error.response?.status,
                url: error.config?.url
            });
            throw error;
        }
    }


    static async getUserTestResults(userId, courseId) {
        try {
            const response = await axios.get(`${API_URL}api/courses/user-test-results/${userId}/courses/${courseId}`);
            return response.data;
        } catch (error) {
            console.error('Error getting test results:', error);
            // Возвращаем null вместо throw
            return null;
        }
    }

    static async getUserStats(userId) {
        try {
            const response = await axios.get(`${API_URL}api/courses/user-stats/${userId}`);
            return response.data;
        } catch (error) {
            console.error('Error getting user stats:', error);
            // Возвращаем null вместо throw
            return null;
        }
    }
}

export default CourseService;